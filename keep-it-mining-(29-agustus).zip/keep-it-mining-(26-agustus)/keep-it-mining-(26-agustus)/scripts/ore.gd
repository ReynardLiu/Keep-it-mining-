extends Area2D

var ore_data: OreData

@onready var sprite_2d: Sprite2D = $Sprite2D
@export var item: InvItem
var player = null

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	sprite_2d.texture = ore_data.texture

'''
func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		body.collect(item)
		if body.add_ore(ore_data):
			player = body
			queue_free()
'''

func _on_body_entered(body: Node2D) -> void:
	if body is Player:
		# Jika data item ternyata kosong, cetak peringatan di konsol agar tidak crash
		if item == null:
			print("Peringatan: Data 'item' pada Ore ini belum diisi!")
			return 
			
		body.collect(item)
		if body.add_ore(ore_data):
			player = body
			queue_free()
