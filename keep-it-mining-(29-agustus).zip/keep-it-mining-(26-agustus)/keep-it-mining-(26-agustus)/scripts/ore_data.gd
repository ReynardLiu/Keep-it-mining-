extends Resource
class_name OreData

@export var name: String
@export var texture: Texture2D
@export var value: int
@export var inventory_item: InvItem
