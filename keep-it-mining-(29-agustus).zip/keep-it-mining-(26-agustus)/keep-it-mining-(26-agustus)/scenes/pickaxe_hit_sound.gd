extends AudioStreamPlayer2D

func pickaxe_sound():
	play()
